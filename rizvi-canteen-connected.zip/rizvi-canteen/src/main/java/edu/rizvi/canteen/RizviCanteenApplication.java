package edu.rizvi.canteen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RizviCanteenApplication {
    public static void main(String[] args) {
        SpringApplication.run(RizviCanteenApplication.class, args);
    }
}
