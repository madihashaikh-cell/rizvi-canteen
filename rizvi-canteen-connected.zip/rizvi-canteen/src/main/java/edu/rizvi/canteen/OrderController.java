package edu.rizvi.canteen;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api")
public class OrderController {
    private final AtomicLong ids = new AtomicLong(1000);
    private final List<MenuItem> menu = new ArrayList<>(List.of(
        new MenuItem(1, "Veg Sandwich", "Snacks", 45, true, 18, "🥪"),
        new MenuItem(2, "Paneer Roll", "Meals", 80, true, 12, "🌯"),
        new MenuItem(3, "Chicken Burger", "Meals", 110, false, 8, "🍔"),
        new MenuItem(4, "Masala Fries", "Snacks", 55, true, 0, "🍟"),
        new MenuItem(5, "Cold Coffee", "Drinks", 60, true, 20, "🥤"),
        new MenuItem(6, "Samosa", "Snacks", 20, true, 30, "🥟"),
        new MenuItem(7, "Veg Thali", "Meals", 95, true, 10, "🍱"),
        new MenuItem(8, "Fresh Lime Soda", "Drinks", 35, true, 16, "🍋")
    ));
    private final Map<Long, Order> orders = new LinkedHashMap<>();

    @GetMapping("/menu")
    public synchronized List<MenuItem> menu() { return menu; }

    @GetMapping("/orders")
    public synchronized Collection<Order> orders() { return orders.values(); }

    @GetMapping("/orders/{id}")
    public synchronized Order order(@PathVariable long id) {
        Order o = orders.get(id);
        if (o == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found");
        return o;
    }

    @PostMapping("/orders")
    public synchronized Order place(@RequestBody NewOrder request) {
        if (request.items() == null || request.items().isEmpty())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty");
        List<OrderLine> lines = new ArrayList<>();
        double total = 0;
        for (CartLine c : request.items()) {
            MenuItem item = menu.stream().filter(m -> m.id() == c.id()).findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown item"));
            if (c.quantity() < 1 || item.stock() < c.quantity())
                throw new ResponseStatusException(HttpStatus.CONFLICT, item.name() + " is sold out or has insufficient stock");
            lines.add(new OrderLine(item.name(), c.quantity(), item.price()));
            total += item.price() * c.quantity();
            int index = menu.indexOf(item);
            menu.set(index, new MenuItem(item.id(), item.name(), item.category(), item.price(),
                item.veg(), item.stock() - c.quantity(), item.emoji()));
        }
        long token = ids.incrementAndGet();
        Order order = new Order(token, request.customer() == null ? "Guest" : request.customer(),
            lines, total, "PLACED", request.pickupSlot() == null ? "Next available" : request.pickupSlot(),
            request.paymentMethod() == null ? "Pay at counter" : request.paymentMethod(),
            LocalDateTime.now().toString());
        orders.put(token, order);
        return order;
    }

    @PatchMapping("/orders/{id}/status")
    public synchronized Order status(@PathVariable long id, @RequestBody StatusUpdate update) {
        Order old = orders.get(id);
        if (old == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found");
        if (!List.of("PLACED", "PREPARING", "READY").contains(update.status()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid status");
        Order next = new Order(old.token(), old.customer(), old.items(), old.total(), update.status(),
            old.pickupSlot(), old.paymentMethod(), old.createdAt());
        orders.put(id, next);
        return next;
    }

    @PostMapping("/menu")
    public synchronized MenuItem addItem(@RequestBody MenuItem item) {
        long nextId = menu.stream().mapToLong(MenuItem::id).max().orElse(0) + 1;
        MenuItem created = new MenuItem(nextId, item.name(), item.category(), item.price(),
            item.veg(), item.stock(), item.emoji() == null ? "🍽️" : item.emoji());
        menu.add(created);
        return created;
    }

    public record MenuItem(long id, String name, String category, double price, boolean veg, int stock, String emoji) {}
    public record CartLine(long id, int quantity) {}
    public record NewOrder(String customer, String pickupSlot, String paymentMethod, List<CartLine> items) {}
    public record OrderLine(String name, int quantity, double unitPrice) {}
    public record Order(long token, String customer, List<OrderLine> items, double total, String status, String pickupSlot, String paymentMethod, String createdAt) {}
    public record StatusUpdate(String status) {}
}
